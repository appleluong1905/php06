<?php
   ob_start();
   session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>San Joaquin Valley Town Hall | speakers and luncheons</title>
		<link rel="shortcut icon" href="favicon.ico">
		<meta charset="utf-8">
		<meta name="description" content="Test HTML5">
		<meta name="keywords" content="Test HTML5">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/style1.css">
	</head>
	<body>