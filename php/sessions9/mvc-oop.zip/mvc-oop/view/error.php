<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Application error</title>
    </head>
    <body>
        <h1><?php echo htmlentities($title) ?></h1>
        <p>
            <?php echo htmlentities($message) ?>
        </p>
    </body>
</html>