<?php

require_once 'controller/users_controller.php';

$controller = new UsersController();

$controller->handleRequest();

?>
