<!DOCTYPE html>
<html>
	<head>
		<title>San Joaquin Valley Town Hall | speakers and luncheons</title>
		<link rel="shortcut icon" href="favicon.ico">
		<meta charset="utf-8">
		<meta name="description" content="Test HTML5">
		<meta name="keywords" content="Test HTML5">
	</head>
	<body>
	<h1>Input your information</h1>
	<form action="insert.php" method="post">
		<p>Name:  <input type="text" name="name"></p>
		<p>Email: <input type="email" name="email"></p>
		<p>Birthday:  <input type="date" name="birthday"></p>
		<p>Phone:  <input type="text" name="phone"></p>
		<p><input type="submit" name="submit" value="Submit"></p>
	</form>
	</body>
</html>