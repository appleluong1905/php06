@extends('layouts.frontend')

@section('content')

<h1>Welcome PHP06</h1>
<p>xin chao</p>

@endsection
